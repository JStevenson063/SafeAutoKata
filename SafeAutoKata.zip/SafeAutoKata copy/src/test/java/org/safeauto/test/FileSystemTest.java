package org.safeauto.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;


import org.junit.After;
import org.junit.Test;
import org.safeauto.Driver;
import org.safeauto.FileSystem;
import org.safeauto.Trip;

public class FileSystemTest {

	FileSystem file = new FileSystem("Test.txt");
	
	
	
	
	@Test
	public void retrieveAllDriversTest() {
		Driver driver = new Driver();
		driver.setName("Bob");
		file.addDriverName(driver);
		List<Driver> driversTest = file.retrieveDriverList();
		
		assertNotNull(driversTest);
		assertEquals("Bob", driversTest.get(0).getName());
	}
	
	@Test
	public void addDriverNameTest() {
		String driverName = "Test";
		Driver driverTest = new Driver();
		driverTest.setName(driverName);
		file.addDriverName(driverTest);
		List<Driver> driversTest = file.retrieveDriverList();
		
		assertEquals(driverName, driversTest.get(driversTest.size() - 1).getName());
	}
	
	@Test
	public void removeDriverNameTest() {
		
		String driverName = "Remove";
		Driver driverTest = new Driver();
		driverTest.setName(driverName);
		file.addDriverName(driverTest);
		file.removeDriverName(driverName);
		List<Driver> driversTest = file.retrieveDriverList();
		
		assertTrue(!driversTest.contains(driverTest));
		
	}
	
	@Test
	public void addTripTest() {
		
		Trip trip = new Trip();
		trip.setName("Test");
		trip.setStartTime("05-02-2020-12:45");
		trip.setEndTime("05-03-2020-12:45");
		trip.setMilesDriven(400);
		file.addTrip(trip);
		List<Trip> tripsTest = file.retrieveTripList();
		
		assertTrue(400.0 == tripsTest.get(tripsTest.size() - 1).getMilesDriven());
		
	}
	
	@Test
	public void retrieveTripListTest() {
		Trip trip = new Trip();
		trip.setName("tripList");
		trip.setStartTime("05-10-2020-12:15");
		trip.setEndTime("05-10-2020-12:30");
		trip.setMilesDriven(3.0);
		file.addTrip(trip);
		List<Trip> tripsTest = file.retrieveTripList();
		
		assertFalse(tripsTest.isEmpty());
		
	}
	
	@After 
	public void cleanUp() {
		file.exit();
	}
}
