package org.safeauto;

import org.safeauto.view.Menu;

public class DriverTrackerCLI {

	private final static int ADD_DRIVER = 1;
	private final static int REMOVE_DRIVER = 2;
	private final static int ADD_TRIP = 3;
	private final static int REMOVE_TRIP = 4;
	private final static int PRINT_REPORT = 5;
	private final static int EXIT = 6;

	private Service service;
	private Menu menu;
	private boolean exit = false;

	public DriverTrackerCLI(Menu menu) {
		this.menu = menu;
		service = new Service();
	}

	public static void main(String[] args) {
		Menu menu = new Menu();
		DriverTrackerCLI cli = new DriverTrackerCLI(menu);
		cli.run();
	}

	public void run() {

		while (!exit) {
			int userChoice = menu.printMainMenu();

			if (userChoice == ADD_DRIVER) {

				Driver driver = menu.addDriver();
				service.addDriverName(driver);

			} else if (userChoice == REMOVE_DRIVER) {

				String driverName = menu.removeDriver();
				service.removeDriverName(driverName);

			} else if (userChoice == ADD_TRIP) {

				Trip trip = menu.addTrip();

				service.addTrip(trip);

			} else if (userChoice == REMOVE_TRIP) {

				int id = menu.removeTrip();
				service.removeTrip(id);

			} else if (userChoice == PRINT_REPORT) {

				menu.printReport();
				service.printReport();

			} else if (userChoice == EXIT) {
				service.exit();
				exit = true;
			}
		}
	}

}
