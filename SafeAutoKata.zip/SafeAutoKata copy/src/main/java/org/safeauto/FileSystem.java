package org.safeauto;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileSystem {

	private File inputFile;
	
	public FileSystem(String pathName) {
		inputFile = new File(pathName);
	}

	public void addDriverName(Driver driver) {

		try {
			FileWriter fw = new FileWriter(inputFile, true);
			PrintWriter printWriter = new PrintWriter(fw);

			printWriter.println("Driver," + driver.getName());
			System.out.println("\nDriver " + driver.getName() + " added!");

			fw.close();
			printWriter.close();

		}

		catch (IOException io) {
			System.out.println("Error Adding Driver...");
			io.printStackTrace();
		}

	}

	public void removeDriverName(String driverName) {

		boolean nameExists = false;

		try {
			File tempFile = new File("tempFile.txt");
			Scanner scanner = new Scanner(inputFile);
			FileWriter fw = new FileWriter(tempFile, true);
			PrintWriter printWriter = new PrintWriter(fw);

			while (scanner.hasNext()) {
				String line = scanner.nextLine();

				if (line.contains(driverName)) {
					nameExists = true;
				}

				if (!line.contains(driverName)) {
					printWriter.println(line);
				}
			}
			if (nameExists == false) {
				System.out.println("\nDriver " + driverName + " does not exist. Please add " + driverName);
			} else {
				System.out.println("\nDriver " + driverName + " removed!");
			}
			scanner.close();
			printWriter.close();
			inputFile.delete();
			tempFile.renameTo(inputFile);

		} catch (IOException io) {
			io.printStackTrace();
		}

	}

	public void addTrip(Trip trip) {

		try {
			FileWriter fw = new FileWriter(inputFile, true);
			PrintWriter printWriter = new PrintWriter(fw);

			printWriter.println("Trip," + trip.getId() + "," + trip.getName() + "," + trip.getStartTime() + ","
					+ trip.getEndTime() + "," + trip.getMilesDriven());
			System.out.println("Trip added!");
			fw.close();
			printWriter.close();
		}

		catch (IOException io) {
			System.out.println("Error Adding Trip...");
			io.printStackTrace();
		}

	}

	// method used to calculate the average speed for a drivers trips based on total
	// miles and to remove trips
	public List<Trip> retrieveTripList() {
		List<Trip> trips = new ArrayList<Trip>();
		try {
			Scanner scanner = new Scanner(inputFile);

			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();

				if (line.contains("Trip")) {

					Trip trip = new Trip();

					String[] tripDetails = line.split(",");

					trip.setId(Integer.parseInt(tripDetails[1]));
					trip.setName(tripDetails[2]);
					trip.setStartTime(tripDetails[3]);
					trip.setEndTime(tripDetails[4]);
					trip.setMilesDriven(Double.parseDouble(tripDetails[5]));

					trips.add(trip);

				}
			}

			scanner.close();

		} catch (IOException io) {
			io.printStackTrace();
		}
		return trips;

	}

	public void removeTrip(List<Trip> trips) {
		try {
			File tempFile = new File("tempFile.txt");
			Scanner scanner = new Scanner(inputFile);
			FileWriter fw = new FileWriter(tempFile, true);
			PrintWriter printWriter = new PrintWriter(fw);

			while (scanner.hasNext()) {
				String line = scanner.nextLine();
				if (!line.contains("Trip")) {
					printWriter.println(line);
				}
			}
			for (Trip trip : trips) {
				printWriter.println("Trip," + trip.getId() + "," + trip.getName() + "," + trip.getStartTime() + ","
						+ trip.getEndTime() + "," + trip.getMilesDriven());
			}
			System.out.println("Trip removed!");

			scanner.close();
			printWriter.close();

			inputFile.delete();
			tempFile.renameTo(inputFile);

		} catch (IOException io) {
			io.printStackTrace();
		}

	}

	// method used to calculate a drivers total miles
	public List<Driver> retrieveDriverList() {

		List<Driver> drivers = new ArrayList<Driver>();

		try {
			Scanner scanner = new Scanner(inputFile);

			while (scanner.hasNextLine()) {

				String line = scanner.nextLine();

				if (line.contains("Driver")) {
					Driver driver = new Driver();

					String[] driverName = line.split(",");

					driver.setName(driverName[1]);

					drivers.add(driver);
				}
			}

			scanner.close();

		} catch (IOException io) {
			io.printStackTrace();
		}
		return drivers;
	}

	// method to reset the TripsAndDrivers.txt file back to empty when program is
	// terminated
	public void exit() {

		File tempFile = new File("tempFile.txt");
		try {
			PrintWriter printWriter = new PrintWriter(tempFile);

			printWriter.close();

			inputFile.delete();
			tempFile.renameTo(inputFile);

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}

	}

}
