package org.safeauto;


public class Trip {

	private static int globalID = 0;
	private String name;
	private String startTime;
	private String endTime;
	private int id;
	private double milesDriven;
	
	public Trip() {
		globalID++;
		id = globalID;
	}
	
	public Trip(int id) {
		globalID = id;
		this.id = globalID;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getMilesDriven() {
		return milesDriven;
	}
	public void setMilesDriven(double milesDriven) {
		this.milesDriven = milesDriven;
	}
	
	
	
}
