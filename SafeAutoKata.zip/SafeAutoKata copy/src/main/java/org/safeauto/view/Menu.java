package org.safeauto.view;

import java.util.List;
import java.util.Scanner;

import org.safeauto.Driver;
import org.safeauto.FileSystem;
import org.safeauto.Trip;

public class Menu {

	FileSystem file = new FileSystem("TripsAndDrivers.txt");

	private Scanner inputScanner = new Scanner(System.in);

	public int printMainMenu() {
		System.out.println("\n*********************");
		System.out.println("(1) Add Driver");
		System.out.println("(2) Remove Driver");
		System.out.println("(3) Add Trip");
		System.out.println("(4) Remove Trip");
		System.out.println("(5) Print Report");
		System.out.println("(6) Exit");
		System.out.println("*********************");

		return inputScanner.nextInt();
	}

	public Driver addDriver() {

		inputScanner.nextLine();

		Driver driver = new Driver();

		System.out.println("Please provide the first name of the driver you'd like to add");

		String name = inputScanner.nextLine();
		driver.setName(name);

		return driver;
	}

	public String removeDriver() {

		inputScanner.nextLine();
		System.out.println("\nPlease provide the first name of the driver you'd like to remove");

		return inputScanner.nextLine();
	}

	public Trip addTrip() {

		Trip trip;
		List<Trip> currentTrips = file.retrieveTripList();

		if (currentTrips.isEmpty()) {

			trip = new Trip();
		} else {
			trip = new Trip(currentTrips.get(currentTrips.size() - 1).getId() + 1);
		}

		inputScanner.nextLine();
		System.out.println("\nPlease provide the following details about the trip to be added");

		System.out.println("\nDriver name: ");
		trip.setName(inputScanner.nextLine());

		System.out.println("\nStart date and time in the following format (05-03-2020-12:45) ");
		trip.setStartTime(inputScanner.nextLine());

		System.out.println("\nEnd date and time in the following format (05-06-2020-14:12)");
		trip.setEndTime(inputScanner.nextLine());

		System.out.println("\nMiles driven on trip");
		String tempMilesDriven = inputScanner.nextLine();
		double milesDriven = Double.parseDouble(tempMilesDriven);
		trip.setMilesDriven(milesDriven);

		return trip;
	}

	public int removeTrip() {

		inputScanner.nextLine();
		System.out.println("\nPlease provide the ID of the trip you'd like to remove: ");

		return inputScanner.nextInt();
	}

	public void printReport() {
		System.out.println("\nDriver Report");
	}

}
