package org.safeauto;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Service {

	// the service layer is used as the go between for the CLI and the FileSystem

	private String dateFormat = "MM-dd-yyyy-HH:mm";
	private DateTimeFormatter dtf = DateTimeFormatter.ofPattern(dateFormat);
	private FileSystem file = new FileSystem("TripsAndDrivers.txt");

	public void addDriverName(Driver driver) {

		file.addDriverName(driver);
	}

	public void removeDriverName(String driverName) {

		file.removeDriverName(driverName);
	}

	public void addTrip(Trip trip) {

		file.addTrip(trip);
	}

	public void removeTrip(int tripID) {
		List<Trip> trips = file.retrieveTripList();
		for (int i = 0; i < trips.size(); i++) {
			if (trips.get(i).getId() == tripID) {
				trips.remove(i);
			}
		}
		file.removeTrip(trips);
	}

	// method used to calculate average speed and print to console based on current
	// drivers and trips
	public void printReport() {

		int milesSum = 0;
		int hoursSum = 0;

		List<Driver> currentDrivers = file.retrieveDriverList();
		List<Trip> currentTrips = file.retrieveTripList();
		List<DriverReport> driverReports = new ArrayList<DriverReport>();

		for (int i = 0; i < currentDrivers.size(); i++) {

			DriverReport driver = new DriverReport();
			driver.setName(currentDrivers.get(i).getName());

			milesSum = 0;
			hoursSum = 0;

			for (int j = 0; j < currentTrips.size(); j++) {

				if (currentDrivers.get(i).getName().equalsIgnoreCase(currentTrips.get(j).getName())) {

					milesSum += (int) currentTrips.get(j).getMilesDriven();

					LocalDateTime startDate = LocalDateTime.parse(currentTrips.get(j).getStartTime(), dtf);
					LocalDateTime endDate = LocalDateTime.parse(currentTrips.get(j).getEndTime(), dtf);

					hoursSum += (int) Duration.between(startDate, endDate).toHours();

				}
			}

			if (hoursSum > 0) {
				driver.setAverageSpeed(milesSum / hoursSum);
			}

			driver.setTotalMiles(milesSum);
			driverReports.add(driver);
		}
		sortDrivers(driverReports);

		for (int i = 0; i < driverReports.size(); i++) {
			if (driverReports.get(i).getTotalMiles() > 0) {
				System.out.println(
						"\n" + driverReports.get(i).getName() + " drove " + driverReports.get(i).getTotalMiles()
								+ " miles at an average of " + driverReports.get(i).getAverageSpeed() + " mph");
			} else {
				System.out.println("\n" + driverReports.get(i).getName() + " drove "
						+ driverReports.get(i).getTotalMiles() + " miles");
			}
		}

	}

	// private helper method to sort drivers from highest miles to lowest
	private List<DriverReport> sortDrivers(List<DriverReport> drivers) {
		Collections.sort(drivers, new Comparator<DriverReport>() {
			public int compare(DriverReport driver1, DriverReport driver2) {
				return driver2.getTotalMiles() - driver1.getTotalMiles();
			}
		});
		return drivers;
	}

	public void exit() {
		file.exit();
	}
}
